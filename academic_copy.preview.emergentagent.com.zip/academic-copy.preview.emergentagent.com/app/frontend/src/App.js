import React, {
    useState,
    useEffect
} from "react";
import "./App.css";
import {
    BrowserRouter,
    Routes,
    Route
} from "react-router-dom";
import Components from "./Components";

function App() {
    return ( <
        div className = "App" >
        <
        BrowserRouter >
        <
        Routes >
        <
        Route path = "/"
        element = { < Components.Homepage / >
        }
        /> <
        /Routes> <
        /BrowserRouter> <
        /div>
    );
}

export default App;